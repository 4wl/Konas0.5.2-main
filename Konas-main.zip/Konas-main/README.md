<p align="center">
 <img src ="https://i.imgur.com/QiDjFLC.png" width="10%" height="10%"/>
 <br>
 <b>
  <a href="https://github.com/charlie353535">Charlie</a> |
  <a href="https://github.com/KohimaNayagato">Denomi</a>
 </b>
</p>

<p align="center"> Released due to Mikhail/GL__DONT__CARE attempting to blackmail (badly) </p>

<p align="center"> Thanks to Crystallinqq for dumping method </p>

<p align="center"> Loader made with swag by Charlie353535, dumped by Denomi </p>
<p align="center"> Please note that Konas is a modification to cookiedragon234's <a href="https://github.com/x4e/Luchadora">Luchadora</a> (Which is licensed under <a href="https://www.gnu.org/licenses/gpl-3.0.en.html">GNU Affero General Public License v3.0</a>) as it uses code which was NOT forked from the original repository and is being used commercially thus releasing this is under no way in violation of the Digital Millennium Copyright Act (DMCA) </p>

<p align="center">Konas for Everyone is a project aimed at providing Konas Client to everyone free of charge. We believe in free proprietary software and Open Source Software (FOSS) license compliance. At Konas for Everyone, we have dedicated time to reverse engineering Konas Client and its obfuscation methods to accomplish our goals.</p>


<p align="center">How to use this:<br>
Put konas.jar in your .minecraft<br>
Put konas-b0.5.2-release.jar in your mods folder<br>
Launch Minecraft.
</p>
